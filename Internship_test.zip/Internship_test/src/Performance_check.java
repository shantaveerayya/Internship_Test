import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;


public class Performance_check {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.gecko.driver", "./softwares/geckodriver.exe");
		WebDriver driver= new FirefoxDriver();
		driver.get("https://www.developer-connector-mern.com/dashboard");
		WebElement logusername=driver.findElement(By.xpath("//input[@name='email']"));
		logusername.sendKeys("shantaveerayya1995@gmail.com");
		WebElement logpwd=driver.findElement(By.xpath("//input[@name='password']"));
		logpwd.sendKeys("Remember123@");
		WebElement logsubmit=driver.findElement(By.xpath("//input[@class='btn btn-info btn-block mt-4']"));
		logsubmit.click();
		Thread.sleep(3000);
		String homeexptitle="https://www.developer-connector-mern.com/dashboard";
		String homeactualtitle=driver.getTitle();
		if(homeexptitle.equals(homeactualtitle))
		{
			System.out.println("Home Page is displayed and test case is passed");
		}
		else
		{
			System.err.println("Home page is not displayed and test case is failed");
		}
		Thread.sleep(3000);
		WebElement postfeed=driver.findElement(By.xpath("//a[@href='/feed']"));
		postfeed.click();
		WebElement posttext=driver.findElement(By.xpath("//textarea[@name='text']"));
		posttext.sendKeys("Let's do best for our clients");
		WebElement post=driver.findElement(By.xpath("//button[@class='btn btn-dark posts-comments__submit-button']"));
		post.click();
		Thread.sleep(3000);
		String postexptitle="https://www.developer-connector-mern.com/feed";
		String postactualtitle=driver.getTitle();
		if(postexptitle.equals(postactualtitle))
		{
			System.out.println("post feed page is displayed and test case is passed");
		}
		else
		{
			System.err.println("post feed page is not displayed and test case is failed");
		}
		Thread.sleep(3000);
		WebElement logout=driver.findElement(By.xpath("//a[@class='nav-link']"));
		logout.click();
	}

}
