import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.seleniumhq.jetty9.security.authentication.LoginAuthenticator;


public class Register_Login_Logout_Script {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.gecko.driver", "./softwares/geckodriver.exe");
		WebDriver driver= new FirefoxDriver();
		driver.get("https://www.developer-connector-mern.com/");
		WebElement reg=driver.findElement(By.xpath("//a[@id='landing__btn-sign-up']"));
		reg.click();
		WebElement name=driver.findElement(By.xpath("//input[@name='name']"));
		name.sendKeys("Shantaveerayya");
		WebElement email=driver.findElement(By.xpath("//input[@name='email']"));
		email.sendKeys("shantaveerayya1995@gmail.com");
		WebElement pwd=driver.findElement(By.xpath("//input[@name='password']"));
		pwd.sendKeys("Remember123@");
		WebElement verpwd=driver.findElement(By.xpath("//input[@name='password2']"));
		verpwd.sendKeys("Remember123@");
		WebElement submit=driver.findElement(By.xpath("//input[@class='btn btn-info btn-block mt-4']"));
		submit.click();
		WebElement login=driver.findElement(By.xpath("//a[@href='/login']"));
		login.click();
		Thread.sleep(3000);
		String regexptitle="https://www.developer-connector-mern.com/login";
		String regactualtitle=driver.getTitle();
		if(regexptitle.equals(regactualtitle))
		{
			System.out.println("Login Page is displayed and test case is passed");
		}
		else
		{
			System.err.println("Login page is not displayed and test case is failed");
		}
		Thread.sleep(2000);
		WebElement logusername=driver.findElement(By.xpath("//input[@name='email']"));
		logusername.sendKeys("shantaveerayya1995@gmail.com");
		WebElement logpwd=driver.findElement(By.xpath("//input[@name='password']"));
		logpwd.sendKeys("Remember123@");
		WebElement logsubmit=driver.findElement(By.xpath("//input[@class='btn btn-info btn-block mt-4']"));
		logsubmit.click();
		Thread.sleep(3000);
		String loginetitle="https://www.developer-connector-mern.com/dashboard";
		String loginatitle=driver.getTitle();
		if(loginetitle.equals(loginatitle))
		{
			System.out.println("Home Page is displayed and test case is passed");
		}
		else
		{
			System.err.println("Home page is not displayed and test case is failed");
		}
		WebElement logout=driver.findElement(By.xpath("//a[@id='navbar__logout-li']"));
		logout.click();
		
	}

}
